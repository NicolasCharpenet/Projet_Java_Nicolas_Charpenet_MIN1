package com.epf.rentmanager.ui.servlets;

import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Vehicule;
import com.epf.rentmanager.service.VehiculeService;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.time.temporal.ValueRange;

@WebServlet("/cars/create")
public class VehiculeCreateServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/vehicules/create.jsp");
        dispatcher.forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Vehicule vehicule = new Vehicule();
        vehicule.setConstructeur(request.getParameter("manufacturer"));
        vehicule.setModele(request.getParameter("modele"));
        vehicule.setNb_places(Integer.parseInt(request.getParameter("seats")));
        VehiculeService vehiculeService = VehiculeService.getInstance();
        try {
            vehiculeService.create(vehicule);
            response.sendRedirect(request.getContextPath()+"/cars");
        } catch (ServiceException e) {
            doGet(request,response);
        }

    }
}
