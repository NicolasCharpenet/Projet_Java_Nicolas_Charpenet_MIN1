package com.epf.rentmanager.dao;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.persistence.ConnectionManager;
import org.springframework.stereotype.Repository;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class ClientDao {
	
	private static ClientDao instance = null;

	/**
	 *
	 */
	private ClientDao() {

	}

	/**
	 * @return
	 */
	/*public static ClientDao getInstance() {
		if(instance == null) {
			instance = new ClientDao();
		}
		return instance;
	}*/
	
	private static final String CREATE_CLIENT_QUERY = "INSERT INTO Client(nom, prenom, email, naissance) VALUES(?, ?, ?, ?);";
	private static final String DELETE_CLIENT_QUERY = "DELETE FROM Client WHERE id=?;";
	private static final String FIND_CLIENT_QUERY = "SELECT id, nom, prenom, email, naissance FROM Client WHERE id=?;";
	private static final String FIND_CLIENTS_QUERY = "SELECT id, nom, prenom, email, naissance FROM Client;";

	/**
	 * @param client
	 * @return
	 * @throws DaoException
	 */
	public long create(Client client) throws DaoException {
		try(
				Connection connection = ConnectionManager.getConnection();
				PreparedStatement createPreparedStatement = connection.prepareStatement(CREATE_CLIENT_QUERY, Statement.RETURN_GENERATED_KEYS)
				) {
			createPreparedStatement.setString(1, client.getNom());
			createPreparedStatement.setString(2, client.getPrenom());
			createPreparedStatement.setString(3, client.getEmail());
			createPreparedStatement.setDate(4, Date.valueOf(client.getNaissance()));
			createPreparedStatement.executeUpdate();
			ResultSet resultSet = createPreparedStatement.getGeneratedKeys();
			int id = 0;
			if(resultSet.next()){
				id = resultSet.getInt(1);
			}
			resultSet.close();
			return id;
		} catch (SQLException throwables) {
			throwables.printStackTrace();
			throw new DaoException(throwables.getMessage());
		}
	}

	/**
	 * @param client
	 * @return
	 * @throws DaoException
	 */
	public long delete(Client client) throws DaoException {
			try(Connection connection = ConnectionManager.getConnection();
				PreparedStatement deletePreparedStatement = connection.prepareStatement(DELETE_CLIENT_QUERY)
			) {
				deletePreparedStatement.setLong(1,client.getId());
				return deletePreparedStatement.executeUpdate();
			} catch (SQLException throwables) {
				throwables.printStackTrace();
				throw new DaoException(throwables.getMessage());
			}
	}

	/**
	 * @param id
	 * @return
	 * @throws DaoException
	 */
	public Optional<Client> findById(long id) throws DaoException {
		try(Connection connection = ConnectionManager.getConnection();
			PreparedStatement findPreparedStatement = connection.prepareStatement(FIND_CLIENT_QUERY)
		) {
			findPreparedStatement.setLong(1, id);
			findPreparedStatement.execute();
			ResultSet resultSet = findPreparedStatement.getResultSet();
			Optional<Client> optionalClient = Optional.empty();
			if(resultSet.next()){
				optionalClient = Optional.of(new Client(id,
						resultSet.getString(2),
						resultSet.getString(3),
						resultSet.getString(4),
						resultSet.getDate(5).toLocalDate()));
			}
			resultSet.close();
			return optionalClient;

		} catch (SQLException throwables) {
			throwables.printStackTrace();
			throw new DaoException(throwables.getMessage());
		}
	}

	/**
	 * @return
	 * @throws DaoException
	 */
	public List<Client> findAll() throws DaoException {
		try(Connection connection = ConnectionManager.getConnection();
			PreparedStatement findAllPreparedStatement = connection.prepareStatement(FIND_CLIENTS_QUERY)
		) {
			findAllPreparedStatement.execute();
			ResultSet resultSet = findAllPreparedStatement.getResultSet();
			List<Client> clients = new ArrayList<>();
			while (resultSet.next()){
				clients.add(new Client(resultSet.getLong(1),
						resultSet.getString(2),
						resultSet.getString(3),
						resultSet.getString(4),
						resultSet.getDate(5).toLocalDate()));
			}
			resultSet.close();
			return clients;
		} catch (SQLException throwables) {
			throwables.printStackTrace();
			throw new DaoException(throwables.getMessage());
		}
	}

}
