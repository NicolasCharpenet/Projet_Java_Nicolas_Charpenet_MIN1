package com.epf.rentmanager.ui.cli;

import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.model.Vehicule;
import com.epf.rentmanager.service.ClientService;
import com.epf.rentmanager.service.ReservationService;
import com.epf.rentmanager.service.VehiculeService;
import com.epf.rentmanager.utils.IOUtils;

import java.util.List;
import java.util.Optional;


public class InterfaceControlleur {
    private static final ClientService clientService = ClientService.getInstance();
    private static final VehiculeService vehiculeService = VehiculeService.getInstance();
    private static final ReservationService reservationService = ReservationService.getInstance();

    public static void main(String[] args) {
        boolean continuer = true;
        while (continuer) {
            System.out.println("------Menu------");
            System.out.println("1.Ajouter un client");
            System.out.println("2.Lister les clients");
            System.out.println("3.Ajouter un véhicule");
            System.out.println("4.Lister tous les véhicules");
            System.out.println("5.Supprimer un client");
            System.out.println("6.Supprimer un véhicule");
            System.out.println("7.Créer une réservation");
            System.out.println("8.Lister toutes les réservations");
            System.out.println("9.Lister toutes les réservations associées à un client");
            System.out.println("10.Lister toutes les réservations associées à un véhicule");
            System.out.println("11.Supprimer une réservation");
            System.out.println("12.Quitter");
            int choix = IOUtils.readInt("Entrer votre choix :");
            try {
                switch (choix) {
                    case 1:
                        createClient();
                        break;
                    case 2:
                        listAllClient();
                        break;
                    case 3:
                        createVehicule();
                        break;
                    case 4:
                        listAllVehicule();
                        break;
                    case 5:
                        deleteClient();
                        break;
                    case 6:
                        deleteVehicule();
                        break;
                    case 7:
                        createReservation();
                        break;
                    case 8:
                        findAllReservation();
                        break;
                    case 9:
                        reservationByClientId();
                        break;
                    case 10:
                        reservationByVehiculeId();
                        break;
                    case 11:
                        deleteReservation();
                        break;
                    case 12:
                        continuer = false;
                        break;
                    default:
                        throw new IllegalStateException("Unexpected value: " + choix);
                }
            } catch (ServiceException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    /**
     * @throws ServiceException
     */
    private static void deleteReservation() throws ServiceException {
        long id_R = IOUtils.readInt("Entrer l'identifiant de la réservation à supprimer");
        Optional<Reservation> reservation1 = reservationService.findResa(id_R);
        if (reservation1.isPresent()) {
            System.out.println(reservation1);
            int decision = IOUtils.readInt("Supprimer? Oui(1) non (2)");
            if (decision == 1) {
                reservationService.delete(reservation1.get());
                System.out.println("La réservation a été supprimée ! ");
            } else {
                System.out.println("Annulation ...");
            }
        } else {
            System.out.println("la réservation n'est pas trouveée.");
        }
    }

    /**
     * @throws ServiceException
     */
    private static void reservationByVehiculeId() throws ServiceException {
        long id_V = IOUtils.readInt("Entrer l'identifiant du véhicule");
        List<Reservation> reservations2 = reservationService.findByVehiculeId(id_V);
        for (Reservation reservationV : reservations2) {
            System.out.println(reservationV);
        }
    }

    /**
     * @throws ServiceException
     */
    private static void reservationByClientId() throws ServiceException {
        long idR = IOUtils.readInt("Entrer l'identifiant du client");
        List<Reservation> reservations1 = reservationService.findByClientId(idR);
        for (Reservation reservationC : reservations1) {
            System.out.println(reservationC);
        }
    }

    /**
     * @throws ServiceException
     */
    private static void createReservation() throws ServiceException {
        Reservation reservation = new Reservation();
        reservation.setClient_id((long) IOUtils.readInt("Numero du client :"));
        reservation.setVehicule_id((long) IOUtils.readInt("ID du véhicule"));
        reservation.setDebut(IOUtils.readDate("Date de début :", true));
        reservation.setFin(IOUtils.readDate("Date de fin", true));
        reservationService.create(reservation);
        System.out.println("la réservation a été créée. ");
    }

    /**
     * @throws ServiceException
     */
    private static void deleteVehicule() throws ServiceException {
        long idV = IOUtils.readInt("Entrer l'identifiant du véhicule à supprimer");
        Optional<Vehicule> vehicule1 = vehiculeService.findById(idV);
        if (vehicule1.isPresent()) {
            System.out.println(vehicule1);
            int decision = IOUtils.readInt("Supprimer? Oui(1) non (2)");
            if (decision == 1) {
                List<Reservation> reservations = reservationService.findByClientId(idV);
                for (Reservation reservation : reservations) {
                    reservationService.delete(reservation);
                }
                vehiculeService.delete(vehicule1.get());
                System.out.println("le véhicule a été supprimé ! ");
            } else {
                System.out.println("Annulation ...");
            }
        }
    }

    /**
     * @throws ServiceException
     */
    private static void deleteClient() throws ServiceException {
        int id = IOUtils.readInt("Entrer l'identifiant de l'utilisateur à supprimer");
        Optional<Client> client1 = clientService.findById((long) id);
        if (client1.isPresent()) {
            System.out.println(client1);
            int decision = IOUtils.readInt("Supprimer? Oui(1) non (2)");
            if (decision == 1) {
                List<Reservation> reservations = reservationService.findByClientId(id);
                for (Reservation reservation : reservations) {
                    reservationService.delete(reservation);
                }
                clientService.delete(client1.get());
                System.out.println("Client supprimé !");
            }else{
                System.out.println("Annulation ...");
            }
        }else{
            System.out.println("le client n'est pas trouveée.");
        }
    }

    /**
     * @throws ServiceException
     */
    private static void listAllVehicule() throws ServiceException {
        List<Vehicule> vehicules = vehiculeService.findAll();
        for (Vehicule vehicule1 : vehicules) {
            System.out.println(vehicule1);
        }
    }

    /**
     * @throws ServiceException
     */
    private static void createVehicule() throws ServiceException {
        Vehicule vehicule = new Vehicule();
        vehicule.setConstructeur(IOUtils.readString("Constructeur :", true));
        vehicule.setModele(IOUtils.readString("Modèle :", true));
        vehicule.setNb_places(IOUtils.readInt("Nombre de places :"));
        vehiculeService.create(vehicule);
        System.out.println("le véhicule a été créé.");
    }

    /**
     * @throws ServiceException
     */
    private static void listAllClient() throws ServiceException {
        List<Client> clients = clientService.findAll();
        for (Client client1 : clients) {
            System.out.println(client1);
        }
    }

    /**
     * @throws ServiceException
     */
    private static void createClient() throws ServiceException {
        Client client = new Client();
        client.setNom(IOUtils.readString("Entrer votre nom :", true));
        client.setPrenom(IOUtils.readString("Entrer votre prénom :", true));
        client.setEmail(IOUtils.readString("Entrer votre adresse email :", true));
        client.setNaissance(IOUtils.readDate("Entrer votre date de naissance :", true));
        clientService.create(client);
        System.out.println("Le client a été crée.");
    }

    /**
     * @throws ServiceException
     */
    private static void findAllReservation() throws ServiceException {
        List<Reservation> reservations = reservationService.findAll();
        for (Reservation reservation1:reservations){
            System.out.println(reservation1);
        }
    }


}
