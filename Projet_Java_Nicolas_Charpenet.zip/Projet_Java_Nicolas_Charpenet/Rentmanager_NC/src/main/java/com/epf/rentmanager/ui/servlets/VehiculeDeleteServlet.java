package com.epf.rentmanager.ui.servlets;

import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.service.VehiculeService;
import com.epf.rentmanager.utils.IOUtils;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "VehiculeDeleteServlet", value = "/cars/delete")
public class VehiculeDeleteServlet extends HttpServlet {
    VehiculeService vehiculeService = VehiculeService.getInstance();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            vehiculeService.delete(vehiculeService.findById(Long.parseLong(request.getParameter("id"))).get());
            response.sendRedirect(request.getContextPath()+"/cars");
        } catch (ServiceException e) {
            IOUtils.print(e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
