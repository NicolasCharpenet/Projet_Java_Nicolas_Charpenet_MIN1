package com.epf.rentmanager.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.model.Vehicule;
import com.epf.rentmanager.persistence.ConnectionManager;
import org.springframework.stereotype.Repository;

@Repository
public class VehiculeDao {
	
	private static VehiculeDao instance = null;

	/**
	 *
	 */
	private VehiculeDao() {}
	public static VehiculeDao getInstance() {
		if(instance == null) {
			instance = new VehiculeDao();
		}
		return instance;
	}
	
	private static final String CREATE_VEHICULE_QUERY = "INSERT INTO Vehicle(constructeur, nb_places, modele) VALUES(?, ?,?);";
	private static final String DELETE_VEHICULE_QUERY = "DELETE FROM Vehicle WHERE id=?;";
	private static final String FIND_VEHICULE_QUERY = "SELECT id, constructeur, nb_places, modele FROM Vehicle WHERE id=?;";
	private static final String FIND_VEHICULES_QUERY = "SELECT id, constructeur, nb_places, modele FROM Vehicle;";

	/**
	 * @param vehicule
	 * @return
	 * @throws DaoException
	 */
	public long create(Vehicule vehicule) throws DaoException {
		try(
				Connection connection = ConnectionManager.getConnection();
				PreparedStatement createPreparedStatement = connection.prepareStatement(CREATE_VEHICULE_QUERY, Statement.RETURN_GENERATED_KEYS)
		) {
			createPreparedStatement.setString(1, vehicule.getConstructeur());
			createPreparedStatement.setLong(2, vehicule.getNb_places());
			createPreparedStatement.setString(3, vehicule.getModele());

			createPreparedStatement.executeUpdate();

			ResultSet resultSet = createPreparedStatement.getGeneratedKeys();

			int id = 0;
			if(resultSet.next()){
				id = resultSet.getInt(1);
			}
			resultSet.close();
			return id;

		} catch (SQLException throwables) {
			throwables.printStackTrace();
			throw new DaoException(throwables.getMessage());
		}

		
	}

	/**
	 * @param vehicule
	 * @return
	 * @throws DaoException
	 */
	public long delete(Vehicule vehicule) throws DaoException {
		try(Connection connection = ConnectionManager.getConnection();
			PreparedStatement deletePreparedStatement = connection.prepareStatement(DELETE_VEHICULE_QUERY)
		) {
			deletePreparedStatement.setLong(1,vehicule.getId());

			//Maj BD
			return deletePreparedStatement.executeUpdate();

		} catch (SQLException throwables) {
			throwables.printStackTrace();
			throw new DaoException(throwables.getMessage());
		}
	}

	/**
	 * @param id
	 * @return
	 * @throws DaoException
	 */
	public Optional<Vehicule> findById(long id) throws DaoException {
		try(Connection connection = ConnectionManager.getConnection();
			PreparedStatement findPreparedStatement = connection.prepareStatement(FIND_VEHICULE_QUERY)
		) {
			findPreparedStatement.setLong(1, id);
			findPreparedStatement.execute();

			ResultSet resultSet = findPreparedStatement.getResultSet();
			Optional<Vehicule> optionalVehicule = Optional.empty();
			if(resultSet.next()){
				optionalVehicule = Optional.of(new Vehicule(id, resultSet.getString(2),
						resultSet.getInt(3),
						resultSet.getString(4)
						));
			}
			resultSet.close();
			return optionalVehicule;

		} catch (SQLException throwables) {
			throwables.printStackTrace();
			throw new DaoException(throwables.getMessage());
		}
	}

	/**
	 * @return
	 * @throws DaoException
	 */
	public List<Vehicule> findAll() throws DaoException {
		try(Connection connection = ConnectionManager.getConnection();
			PreparedStatement findAllPreparedStatement = connection.prepareStatement(FIND_VEHICULES_QUERY)
		) {
			findAllPreparedStatement.execute();
			ResultSet resultSet = findAllPreparedStatement.getResultSet();
			List<Vehicule> vehicules = new ArrayList<>();
			while (resultSet.next()){
				vehicules.add(new Vehicule(resultSet.getLong(1),
						resultSet.getString(2),
						resultSet.getInt(3),
						resultSet.getString(4)
						));
			}
			resultSet.close();
			return vehicules;
		} catch (SQLException throwables) {
			throwables.printStackTrace();
			throw new DaoException(throwables.getMessage());
		}
	}


}
