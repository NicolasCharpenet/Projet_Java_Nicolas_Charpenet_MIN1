package com.epf.rentmanager.service;

import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.Optional;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.dao.ClientDao;
import com.epf.rentmanager.model.Reservation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClientService {
	@Autowired
	private final ClientDao clientDao;
	@Autowired
	public ClientService instance;
	@Autowired
	public ReservationService reservationService;

	
	ClientService(ClientDao clientDao, ReservationService reservationService) {
		this.clientDao = clientDao;
		this.reservationService = reservationService;
	}


	/**
	 * @return
	 */

	 /*public static ClientService getInstance() {
		if (instance == null) {
			instance = new ClientService();
		}
		
		return instance;
	}*/

	/**
	 * @return
	 * @throws ServiceException
	 */
	public List<Client> findAll() throws ServiceException {
		try {
			return clientDao.findAll();
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}

	/**
	 * @param id
	 * @return
	 * @throws ServiceException
	 */
	public Optional<Client> findById(Long id) throws ServiceException{
		try {
			return clientDao.findById(id);
		} catch (DaoException e) {
			throw new ServiceException("Client introuvable :"+e);
		}
	}

	/**
	 * @param client
	 * @throws ServiceException
	 */
	public void create(Client client) throws ServiceException {
		validateClient(client);
		try {
			clientDao.create(client);
		} catch (DaoException e) {
			throw new ServiceException("Une erreur a eu lieu lors de la création du client.");
		}
	}

	/**
	 * @param client
	 * @throws ServiceException
	 */
	private void validateClient(Client client) throws ServiceException {
		if (client.getNom() == null  || client.getPrenom().equals("")) {
			throw new ServiceException("Tous les champs doivent être remplis !");
		} else if(!client.getEmail().matches(".+@.+\\..+")) {
			throw new ServiceException("Entrer un email valide");
		}else if(Period.between(client.getNaissance(), LocalDate.now()).getYears()<18){
			throw new ServiceException("Interdit au moins de 18 ans");
		}
	}

	/**
	 * @param client
	 * @throws ServiceException
	 */
	public void delete(Client client) throws ServiceException {
		try {
			List<Reservation> reservations = reservationService.findByClientId(client.getId());
			for (Reservation reservation : reservations) {
				reservationService.delete(reservation);
			}
			clientDao.delete(client);
		} catch (DaoException e) {
			throw new ServiceException("Erreur lors de la suppression du client.");
		}
	}
}
