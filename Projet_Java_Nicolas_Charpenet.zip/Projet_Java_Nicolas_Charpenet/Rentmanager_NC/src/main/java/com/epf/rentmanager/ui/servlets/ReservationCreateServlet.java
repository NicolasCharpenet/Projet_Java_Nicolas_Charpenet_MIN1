package com.epf.rentmanager.ui.servlets;

import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.service.ClientService;
import com.epf.rentmanager.service.ReservationService;
import com.epf.rentmanager.service.VehiculeService;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@WebServlet("/rents/create")
public class ReservationCreateServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/rents/create.jsp");
        ClientService clientService = ClientService.getInstance();
        VehiculeService vehiculeService = VehiculeService.getInstance();

        try {
            request.setAttribute("vehicules",vehiculeService.findAll());
            request.setAttribute("clients",clientService.findAll());
        } catch (ServiceException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        dispatcher.forward(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Reservation reservation = new Reservation();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        reservation.setClient_id(Long.valueOf(request.getParameter("client")));
        reservation.setVehicule_id(Long.valueOf(request.getParameter("car")));
        reservation.setDebut(LocalDate.parse(request.getParameter("begin"),formatter));
        reservation.setFin(LocalDate.parse(request.getParameter("end"),formatter));
        ReservationService reservationService = ReservationService.getInstance();
        try {
            reservationService.create(reservation);
            response.sendRedirect(request.getContextPath()+"/rents");
        } catch (ServiceException e) {
            System.out.println(e.getMessage());
            doGet(request,response);
        }
    }
}
