package com.epf.rentmanager.service;

import java.util.List;
import java.util.Optional;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.model.Vehicule;
import com.epf.rentmanager.dao.VehiculeDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VehiculeService {
    private VehiculeDao vehiculeDao;
    public ReservationService reservationService;

    /**
     *
     */
    @Autowired
    public VehiculeService(VehiculeDao vehiculeDao, ReservationService reservationService ) {
        this.vehiculeDao = vehiculeDao;
        this.reservationService = reservationService;
    }

    /**
     * @return
     */
    /*
    public static VehiculeService getInstance() {
        if (instance == null) {
            instance = new VehiculeService();
        }

        return instance;
    }*/

    /**
     * @return
     * @throws ServiceException
     */
    public List<Vehicule> findAll() throws ServiceException {
        try {
            return vehiculeDao.findAll();
        } catch (DaoException e) {
            throw new ServiceException(e.getMessage());
        }


    }

    /**
     * @param id
     * @return
     * @throws ServiceException
     */
    public Optional<Vehicule> findById(long id) throws ServiceException{
        try {
            return vehiculeDao.findById(id);
        } catch (DaoException e) {
            throw new ServiceException(e.getMessage());
        }
    }

    /**
     * @param vehicule
     * @throws ServiceException
     */
    public void create(Vehicule vehicule) throws ServiceException {
        if (vehicule.getConstructeur() == null) {
            throw new ServiceException("Le champ 'constructeur' doit être rempli !");
        }
        try {
            vehiculeDao.create(vehicule);
        } catch (DaoException e) {
            throw new ServiceException("Une erreur a eu lieu lors de la création du véhicule");
        }
    }

    /**
     * @param vehicule
     * @throws ServiceException
     */
    public void delete(Vehicule vehicule) throws ServiceException{
        try{
            List<Reservation> reservations = reservationService.findByVehiculeId(vehicule.getId());
            for (Reservation reservation : reservations) {
                reservationService.delete(reservation);
            }
            vehiculeDao.delete(vehicule);
        } catch (DaoException e) {
            throw new ServiceException("Erreur lors de la suppression du vehicule");
        }
    }
}
