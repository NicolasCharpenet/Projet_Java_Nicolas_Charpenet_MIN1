package com.epf.rentmanager.model;

import java.sql.Date;

public class Vehicule {
    private long id;
    private String constructeur;
    private int nb_places;
    private String modele;

    public Vehicule(){

    }

    public Vehicule(long id, String constructeur, int nb_places, String modele) {
        this.id = id;
        this.constructeur = constructeur;
        this.nb_places = nb_places;
        this.modele = modele;
    }

    @java.lang.Override
    public java.lang.String toString() {
        return "Vehicule{" +
                "id=" + id +
                ", constructeur='" + constructeur + '\'' +
                ", nb_places=" + nb_places +
                ", modele='" + modele + '\'' +
                '}';
    }

    public long getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getConstructeur() {
        return constructeur;
    }

    public void setConstructeur(String constructeur) {
        this.constructeur = constructeur;
    }

    public int getNb_places() {
        return nb_places;
    }

    public void setNb_places(int nb_places) {
        this.nb_places = nb_places;
    }

    public String getModele() {
        return modele;
    }

    public void setModele(String modele) {
        this.modele = modele;
    }
}