package com.epf.rentmanager.exception;

public class ServiceException extends Exception {

    /**
     * @param message
     */
    public ServiceException(String message) {
        super(message);
    }

}