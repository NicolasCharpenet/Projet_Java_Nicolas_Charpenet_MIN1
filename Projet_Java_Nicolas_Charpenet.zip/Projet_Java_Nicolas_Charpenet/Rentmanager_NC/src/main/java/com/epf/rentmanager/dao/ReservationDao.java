 package com.epf.rentmanager.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.persistence.ConnectionManager;
import org.springframework.stereotype.Repository;

 @Repository
public class ReservationDao {

	private static ReservationDao instance = null;

	/**
	 *
	 */
	private ReservationDao() {}
	public static ReservationDao getInstance() {
		if(instance == null) {
			instance = new ReservationDao();
		}
		return instance;
	}

	private static final String CREATE_RESERVATION_QUERY = "INSERT INTO Reservation(client_id, vehicle_id, debut, fin) VALUES(?, ?, ?, ?);";
	private static final String DELETE_RESERVATION_QUERY = "DELETE FROM Reservation WHERE id=?;";
	private static final String FIND_RESERVATIONS_BY_CLIENT_QUERY = "SELECT id, client_id, vehicle_id, debut, fin FROM Reservation WHERE client_id=?;";
	private static final String FIND_RESERVATIONS_BY_VEHICULE_QUERY = "SELECT id, client_id, vehicle_id, debut, fin FROM Reservation WHERE vehicle_id=?;";
	private static final String FIND_RESERVATIONS_QUERY = "SELECT id, client_id, vehicle_id, debut, fin FROM Reservation;";
	private static final String FIND_RESERVATION_QUERY = "SELECT id, client_id, vehicle_id, debut, fin FROM Reservation WHERE id=?;";
	private static final String FIND_RESER_CLIENT_VEH = "SELECT id.Reservation, nom.Client, constructeur.Vehicle, modele.Constructeur, debut, fin FROM Reservation INNER JOIN Client ON client_id.Reservation = id.Client INNER JOIN Vehicle ON vehicule_id.Reservation = id.Vehicle;";

	/**
	 * @param reservation
	 * @return
	 * @throws DaoException
	 */
	public long create(Reservation reservation) throws DaoException {
		try (Connection connection = ConnectionManager.getConnection();
			 PreparedStatement createPreparedStatement = connection.prepareStatement(CREATE_RESERVATION_QUERY, Statement.RETURN_GENERATED_KEYS)
		) {
			createPreparedStatement.setLong(1,reservation.getClient_id());
			createPreparedStatement.setLong(2,reservation.getVehicule_id());
			createPreparedStatement.setDate(3,Date.valueOf(reservation.getDebut()));
			createPreparedStatement.setDate(4,Date.valueOf(reservation.getFin()));

			createPreparedStatement.executeUpdate();

			ResultSet resultSet = createPreparedStatement.getGeneratedKeys();

			int id = 0;
			if(resultSet.next()){
				id = resultSet.getInt(1);
			}
			resultSet.close();
			return id;

		} catch (SQLException throwables) {
			throwables.printStackTrace();
			throw new DaoException(throwables.getMessage());
		}

	}

	/**
	 * @param reservation
	 * @return
	 * @throws DaoException
	 */
	public long delete(Reservation reservation) throws DaoException {
		try (Connection connection = ConnectionManager.getConnection();
			 PreparedStatement deletePreparedStatement = connection.prepareStatement(DELETE_RESERVATION_QUERY)
		) {
			deletePreparedStatement.setLong(1, reservation.getId());
			return deletePreparedStatement.executeUpdate();

		} catch (SQLException throwables) {
			throwables.printStackTrace();
			throw new DaoException(throwables.getMessage());
		}
	}


	/**
	 * @param clientId
	 * @return
	 * @throws DaoException
	 */
	public List<Reservation> findResaByClientId(long clientId) throws DaoException {
		try (Connection connection = ConnectionManager.getConnection();
			 PreparedStatement findResaPreparedStatement = connection.prepareStatement(FIND_RESERVATIONS_BY_CLIENT_QUERY)
		) {
			findResaPreparedStatement.setLong(1, clientId);
			findResaPreparedStatement.execute();

			ResultSet resultSet = findResaPreparedStatement.getResultSet();
			List<Reservation> reservations = new ArrayList<>();
			while (resultSet.next()) {
				reservations.add(new Reservation(resultSet.getLong(1),clientId,
						resultSet.getLong(3),
						resultSet.getDate(4).toLocalDate(),
						resultSet.getDate(5).toLocalDate()));
			}
			resultSet.close();
			return reservations;

		} catch (SQLException throwables) {
			throwables.printStackTrace();
			throw new DaoException(throwables.getMessage());
		}
	}

	/**
	 * @param vehiculeId
	 * @return
	 * @throws DaoException
	 */
	public List<Reservation> findResaByVehiculeId(long vehiculeId) throws DaoException {
		try (Connection connection = ConnectionManager.getConnection();
			 PreparedStatement findResaPreparedStatement = connection.prepareStatement(FIND_RESERVATIONS_BY_VEHICULE_QUERY)
		) {
			findResaPreparedStatement.setLong(1, vehiculeId);
			findResaPreparedStatement.execute();

			ResultSet resultSet = findResaPreparedStatement.getResultSet();
			List<Reservation> reservations = new ArrayList<>();
			while (resultSet.next()) {
				reservations.add(new Reservation(resultSet.getLong(1),
						resultSet.getLong(2),
						vehiculeId,
						resultSet.getDate(4).toLocalDate(),
						resultSet.getDate(5).toLocalDate()));
			}
			resultSet.close();
			return reservations;

		} catch (SQLException throwables) {
			throwables.printStackTrace();
			throw new DaoException(throwables.getMessage());
		}
	}

	/**
	 * @return
	 * @throws DaoException
	 */
	public List<Reservation> findAll() throws DaoException {
		try(Connection connection = ConnectionManager.getConnection();
			PreparedStatement findAllPreparedStatement = connection.prepareStatement(FIND_RESERVATIONS_QUERY)
		) {
			findAllPreparedStatement.execute();
			ResultSet resultSet = findAllPreparedStatement.getResultSet();
			List<Reservation> reservations = new ArrayList<>();
			while (resultSet.next()){
				reservations.add(new Reservation(resultSet.getLong(1),
						resultSet.getLong(2),
						resultSet.getLong(3),
						resultSet.getDate(4).toLocalDate(),
						resultSet.getDate(5).toLocalDate()));
			}
			resultSet.close();
			return reservations;
		} catch (SQLException throwables) {
			throwables.printStackTrace();
			throw new DaoException(throwables.getMessage());
		}
	}

	/**
	 * @param id
	 * @return
	 * @throws DaoException
	 */
	public Optional<Reservation> findResa(long id) throws DaoException{
		try(Connection connection = ConnectionManager.getConnection();
			PreparedStatement findPreparedStatement = connection.prepareStatement(FIND_RESERVATION_QUERY)
		) {
			findPreparedStatement.setLong(1, id);
			findPreparedStatement.execute();

			ResultSet resultSet = findPreparedStatement.getResultSet();
			Optional<Reservation> optionalReservation = Optional.empty();
			if(resultSet.next()){
				optionalReservation = Optional.of(new Reservation(id,
						resultSet.getLong(2),
						resultSet.getLong(3),
						resultSet.getDate(4).toLocalDate(),
						resultSet.getDate(5).toLocalDate()));
			}
			resultSet.close();
			return optionalReservation;

		} catch (SQLException throwables) {
			throwables.printStackTrace();
			throw new DaoException(throwables.getMessage());
		}
	}
}
