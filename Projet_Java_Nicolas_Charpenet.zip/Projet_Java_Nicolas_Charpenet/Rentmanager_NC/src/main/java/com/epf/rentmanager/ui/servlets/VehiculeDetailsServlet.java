package com.epf.rentmanager.ui.servlets;

import com.epf.rentmanager.service.ReservationService;
import com.epf.rentmanager.service.VehiculeService;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "VehiculeDetailsServlet", value = "/cars/details")
public class VehiculeDetailsServlet extends HttpServlet {
    VehiculeService vehiculeService = VehiculeService.getInstance();
    ReservationService reservationService =ReservationService.getInstance();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/vehicules/details.jsp");
        try {
            long id = Long.parseLong(request.getParameter("id"));
            request.setAttribute("vehicule", vehiculeService.findById(id).get());
            request.setAttribute("reservations", reservationService.findByVehiculeId(id));
            request.setAttribute("nombre_Reservations", reservationService.findByVehiculeId(id).size());
        } catch (Exception e) {
            e.printStackTrace();
        }
        dispatcher.forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
