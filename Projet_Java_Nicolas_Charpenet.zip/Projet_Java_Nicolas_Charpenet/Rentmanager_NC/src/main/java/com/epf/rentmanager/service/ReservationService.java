package com.epf.rentmanager.service;

import com.epf.rentmanager.dao.ReservationDao;
import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.model.Vehicule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ReservationService {
    @Autowired
    private ReservationDao reservationDao;
    @Autowired
    public  ReservationService instance;
    @Autowired
    private ClientService clientService;
    @Autowired
    private VehiculeService vehiculeService;

    /**
     *
     */
    @Autowired
    private ReservationService() {
        this.reservationDao = ReservationDao.getInstance();
    }

   /**
     * @return
     */
   /*
    public static ReservationService getInstance() {
        if (instance == null) {
            instance = new ReservationService();
        }

        return instance;
    }*/

    /**
     * @return
     * @throws ServiceException
     */
    public List<Reservation> findAll() throws ServiceException {
        try {
            return reservationDao.findAll();
        } catch (DaoException e) {
            throw new ServiceException(e.getMessage());
        }
    }

    /**
     * @param clientId
     * @return
     * @throws ServiceException
     */
    public List<Reservation> findByClientId(long clientId) throws ServiceException {
        try {
            return reservationDao.findResaByClientId(clientId);
        } catch (DaoException e) {
            throw new ServiceException(e.getMessage());
        }
    }

    /**
     * @param vehiculeId
     * @return
     * @throws ServiceException
     */
    public List<Reservation> findByVehiculeId(long vehiculeId) throws ServiceException {
        try {
            return reservationDao.findResaByVehiculeId(vehiculeId);
        } catch (DaoException e) {
            throw new ServiceException(e.getMessage());
        }
    }


    /**
     * @param reservation
     * @throws ServiceException
     */
    public void create(Reservation reservation) throws ServiceException {
        if(reservation.getClient_id().equals("") || reservation.getClient_id().equals("") || reservation.getDebut().equals("") || reservation.getFin().equals("")){
            throw new ServiceException("Tous les champs doivent être remplis !");
        } else if (clientService.findById(reservation.getClient_id()).isPresent() || vehiculeService.findById(reservation.getVehicule_id()).isPresent()) {
            try{
                reservationDao.create(reservation);
            } catch (DaoException e) {
                throw new ServiceException("Erreur lors de la création de la réservation :"+e);
            }
        }
    }

    /**
     * @param id
     * @return
     * @throws ServiceException
     */
    public Optional<Reservation> findResa(long id) throws ServiceException{
        try {
            return reservationDao.findResa(id);
        } catch (DaoException e) {
            throw new ServiceException(e.getMessage());
        }
    }

    /**
     * @param reservation
     * @throws ServiceException
     */
    public void delete(Reservation reservation) throws ServiceException{
        try{
            reservationDao.delete(reservation);
        } catch (DaoException e) {
            throw new ServiceException("Erreur lors de la suppression de la reservation :"+e);
        }
    }
}
