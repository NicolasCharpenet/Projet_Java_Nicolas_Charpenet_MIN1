package com.epf.rentmanager.ui.servlets;

import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Vehicule;
import com.epf.rentmanager.service.ClientService;
import com.epf.rentmanager.service.VehiculeService;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@WebServlet("/users/create")
public class ClientCreateServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/users/create.jsp");
        dispatcher.forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Client client = new Client();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        client.setNom(request.getParameter("last_name"));
        client.setPrenom(request.getParameter("first_name"));
        client.setNaissance(LocalDate.parse(request.getParameter("naissance"),formatter));
        client.setEmail(request.getParameter("email"));
        ClientService clientService = ClientService.getInstance();
        try {
            clientService.create(client);
            response.sendRedirect(request.getContextPath()+"/users");
        } catch (ServiceException e) {
            System.out.println(e.getMessage());
            doGet(request,response);
        }
    }
}
