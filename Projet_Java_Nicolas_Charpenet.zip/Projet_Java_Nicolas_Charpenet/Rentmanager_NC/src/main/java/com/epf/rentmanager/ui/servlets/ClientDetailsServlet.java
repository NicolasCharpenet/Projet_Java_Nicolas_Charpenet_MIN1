package com.epf.rentmanager.ui.servlets;

import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.service.ClientService;
import com.epf.rentmanager.service.ReservationService;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/users/details")
public class ClientDetailsServlet extends HttpServlet {
    ClientService clientService = ClientService.getInstance();
    ReservationService reservationService = ReservationService.getInstance();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/users/details.jsp");
        try {
            long id = Long.parseLong(request.getParameter("id"));
            request.setAttribute("reservations", reservationService.findByClientId(id));
            request.setAttribute("client", clientService.findById(id).get());


            request.setAttribute("nombre_Reservations", reservationService.findByClientId(id).size());
        } catch (Exception e) {
            e.printStackTrace();
        }
        dispatcher.forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
